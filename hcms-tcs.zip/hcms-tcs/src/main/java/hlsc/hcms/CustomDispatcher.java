package hlsc.hcms;

import jakarta.annotation.Nonnull;
import org.opentcs.components.kernel.Dispatcher;
import org.opentcs.components.kernel.dipatching.TransportOrderAssignmentException;
import org.opentcs.data.model.Vehicle;
import org.opentcs.data.order.ReroutingType;
import org.opentcs.data.order.TransportOrder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CustomDispatcher implements Dispatcher {
  private static final Logger LOG = LoggerFactory.getLogger(CustomDispatcher.class);

  @Override
  public void dispatch() {

  }

  @Override
  public void withdrawOrder(
      @Nonnull
      TransportOrder order, boolean immediateAbort
  ) {

  }

  @Override
  public void withdrawOrder(
      @Nonnull
      Vehicle vehicle, boolean immediateAbort
  ) {

  }

  @Override
  public void reroute(
      @Nonnull
      Vehicle vehicle,
      @Nonnull
      ReroutingType reroutingType
  ) {

  }

  @Override
  public void rerouteAll(
      @Nonnull
      ReroutingType reroutingType
  ) {

  }

  @Override
  public void assignNow(
      @Nonnull
      TransportOrder transportOrder
  )
      throws TransportOrderAssignmentException {

  }

  @Override
  public void initialize() {
    LOG.info("》》》》》》自定义调度器已被加载");
  }

  @Override
  public boolean isInitialized() {
    return false;
  }

  @Override
  public void terminate() {

  }
}
