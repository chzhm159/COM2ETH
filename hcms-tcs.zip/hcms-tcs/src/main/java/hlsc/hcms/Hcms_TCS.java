package hlsc.hcms;
import org.opentcs.customizations.kernel.KernelInjectionModule;

public class Hcms_TCS extends KernelInjectionModule {
  @Override
  protected void configure(){
//    configureSomeDispatcherDependencies();
    bindDispatcher(CustomDispatcher.class);
  }
}
